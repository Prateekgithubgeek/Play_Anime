package com.example.anime

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
