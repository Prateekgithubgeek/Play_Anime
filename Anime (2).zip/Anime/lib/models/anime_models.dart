class AnimeSummary {
  final String id;
  final String title;
  final String image;

  AnimeSummary({required this.id, required this.title, required this.image});

  factory AnimeSummary.fromJson(Map<String, dynamic> json) {
    return AnimeSummary(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      image: json['image'] ?? '',
    );
  }
}

class AnimeInfo {
  final String id;
  final String title;
  final String image;
  final String description;
  final List<Episode> episodes;

  AnimeInfo({
    required this.id,
    required this.title,
    required this.image,
    required this.description,
    required this.episodes,
  });

  factory AnimeInfo.fromJson(Map<String, dynamic> json) {
    return AnimeInfo(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      image: json['image'] ?? '',
      description: json['description'] ?? '',
      episodes: (json['episodes'] as List? ?? [])
          .map((e) => Episode.fromJson(e))
          .toList(),
    );
  }
}

class Episode {
  final String id;
  final String title;
  final int number;

  Episode({required this.id, required this.title, required this.number});

  factory Episode.fromJson(Map<String, dynamic> json) {
    return Episode(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      number: json['number'] ?? 0,
    );
  }
}
