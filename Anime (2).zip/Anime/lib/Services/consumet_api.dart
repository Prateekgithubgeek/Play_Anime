import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:anime/models/anime_models.dart';

class AnimeApi {
  static const String _base = 'https://anime-api.hisoka17.repl.co';

  // 🔹 Search anime
  static Future<List<AnimeSummary>> search(String query) async {
    final uri = Uri.parse('$_base/search?query=$query');
    final res = await http.get(uri);
    if (res.statusCode != 200) throw Exception('Failed: ${res.statusCode}');
    final data = jsonDecode(res.body);

    final List list = (data as List?) ?? [];
    return list.map((e) => AnimeSummary.fromJson(e)).toList();
  }

  // 🔹 Get anime info by id
  static Future<AnimeInfo> info(String id) async {
    final uri = Uri.parse('$_base/anime/$id');
    final res = await http.get(uri);
    if (res.statusCode != 200) throw Exception('Failed: ${res.statusCode}');
    final data = jsonDecode(res.body);
    return AnimeInfo.fromJson(data);
  }

  // 🔹 Get episodes for an anime
  static Future<List<Map<String, dynamic>>> episodes(String id) async {
    final uri = Uri.parse('$_base/anime/$id/episodes');
    final res = await http.get(uri);
    if (res.statusCode != 200) throw Exception('Failed: ${res.statusCode}');
    final data = jsonDecode(res.body);

    return (data as List).map((e) => e as Map<String, dynamic>).toList();
  }

  // 🔹 Get stream URL for an episode
  static Future<String> episodeStreamUrl(String episodeId) async {
    final uri = Uri.parse('$_base/stream/$episodeId');
    final res = await http.get(uri);
    if (res.statusCode != 200) throw Exception('Failed: ${res.statusCode}');
    final data = jsonDecode(res.body);

    if (data['headers'] != null && data['headers']['Referer'] != null) {
      // some streams require Referer header
    }

    return data['url'] ?? '';
  }
}
