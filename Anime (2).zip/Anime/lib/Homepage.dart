import 'package:flutter/material.dart';

class AnimeHomePage extends StatefulWidget {
  @override
  _AnimeHomePageState createState() => _AnimeHomePageState();
}

class _AnimeHomePageState extends State<AnimeHomePage> {
  TextEditingController searchController = TextEditingController();
  List<Map<String, dynamic>> results = [];
  bool loading = false;

  // ✅ Posters (only ONE list now)
  final List<String> animePosters = [
    "https://cdn.myanimelist.net/images/anime/10/47347.jpg", // Attack on Titan
    "https://cdn.myanimelist.net/images/anime/1517/100633.jpg", // Demon Slayer
    "https://cdn.myanimelist.net/images/anime/5/17407.jpg", // Death Note
    "https://cdn.myanimelist.net/images/anime/1223/96541.jpg", // One Punch Man
    "https://cdn.myanimelist.net/images/anime/4/19644.jpg", // FMAB
    "https://cdn.myanimelist.net/images/anime/3/40451.jpg", // Naruto Shippuden
    "https://cdn.myanimelist.net/images/anime/13/17405.jpg", // Code Geass
    "https://cdn.myanimelist.net/images/anime/5/73199.jpg", // Your Name
    "https://cdn.myanimelist.net/images/anime/12/76049.jpg", // My Hero Academia
    "https://cdn.myanimelist.net/images/anime/1988/93649.jpg", // Jujutsu Kaisen
    "https://cdn.myanimelist.net/images/anime/7/8928.jpg", // Bleach
    "https://cdn.myanimelist.net/images/anime/11/39717.jpg", // Hunter x Hunter
    "https://cdn.myanimelist.net/images/anime/3/72078.jpg", // Tokyo Ghoul
    "https://cdn.myanimelist.net/images/anime/2/75234.jpg", // Re:Zero
    "https://cdn.myanimelist.net/images/anime/1795/95088.jpg", // Sword Art Online
    "https://cdn.myanimelist.net/images/anime/11/82209.jpg", // Erased
    "https://cdn.myanimelist.net/images/anime/8/77831.jpg", // Akame ga Kill
    "https://cdn.myanimelist.net/images/anime/3/67177.jpg", // Noragami
    "https://cdn.myanimelist.net/images/anime/2/88336.jpg", // Black Clover
    "https://cdn.myanimelist.net/images/anime/6/79597.jpg", // Dr. Stone
    "https://cdn.myanimelist.net/images/anime/1764/93211.jpg", // Shield Hero
    "https://cdn.myanimelist.net/images/anime/1447/91835.jpg", // Vinland Saga
    "https://cdn.myanimelist.net/images/anime/1806/102576.jpg", // Fire Force
    "https://cdn.myanimelist.net/images/anime/3/17903.jpg", // Elfen Lied
    "https://cdn.myanimelist.net/images/anime/5/73406.jpg", // Angel Beats
    "https://cdn.myanimelist.net/images/anime/2/27873.jpg", // Clannad
    "https://cdn.myanimelist.net/images/anime/3/22061.jpg", // Steins;Gate
    "https://cdn.myanimelist.net/images/anime/9/9453.jpg", // Fairy Tail
  ];
  final List<String> animeTitles = [
    "Attack on Titan",
    "Demon Slayer",
    "Death Note",
    "One Punch Man",
    "Fullmetal Alchemist: Brotherhood",
    "Naruto Shippuden",
    "Code Geass",
    "Your Name",
    "My Hero Academia",
    "Jujutsu Kaisen",
    "Bleach",
    "Hunter x Hunter",
    "Tokyo Ghoul",
    "Re:Zero",
    "Sword Art Online",
    "Erased",
    "Akame ga Kill!",
    "Noragami",
    "Black Clover",
    "Dr. Stone",
    "The Rising of the Shield Hero",
    "Vinland Saga",
    "Fire Force",
    "Elfen Lied",
    "Angel Beats!",
    "Clannad",
    "Steins;Gate",
    "Fairy Tail",
  ];


  // ✅ Hardcoded Anime DB with posters
  late final List<Map<String, dynamic>> allAnime = List.generate(120, (i) {
    return {
      "id": "anime_$i",
      "title": animeTitles[i % animeTitles.length],
      "image": animePosters[i % animePosters.length], // cycle posters
      "description":
      "This is a placeholder description for Anime $animeTitles. It has action, comedy, drama and more!",
      "episodes": List.generate(12, (e) {
        return {
          "id": "ep_${i}_$e",
          "number": e + 1,
          "title": "Episode ${e + 1}",
        };
      }),
    };
  });

  @override
  void initState() {
    super.initState();
    results = allAnime;
  }

  void searchAnime(String query) {
    setState(() {
      if (query.isEmpty) {
        results = allAnime;
      } else {
        results = allAnime
            .where((anime) =>
            anime["title"].toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  void openAnimeDetail(Map<String, dynamic> anime) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AnimeDetailPage(anime: anime),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title:
        Text("Play Anime", style: TextStyle(fontWeight: FontWeight.bold,
          color: Colors.white,
















        ),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepPurple, Colors.pink],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(12),
            child: TextField(
              controller: searchController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: "Search anime...",
                hintStyle: TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.grey[900],
                suffixIcon: IconButton(
                  icon: Icon(Icons.search, color: Colors.white),
                  onPressed: () => searchAnime(searchController.text),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: searchAnime,
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(8),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.65,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: results.length,
              itemBuilder: (context, index) {
                final anime = results[index];
                return GestureDetector(
                  onTap: () => openAnimeDetail(anime),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.grey[900],
                      boxShadow: [
                        BoxShadow(
                          color: Colors.purple.withOpacity(0.5),
                          blurRadius: 8,
                          offset: Offset(0, 4),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius:
                            BorderRadius.vertical(top: Radius.circular(16)),
                            child: Image.network(
                              anime["image"],
                              fit: BoxFit.cover,
                              errorBuilder: (c, e, s) => Icon(
                                Icons.broken_image,
                                color: Colors.grey,
                                size: 50,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            anime["title"],
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

class AnimeDetailPage extends StatelessWidget {
  final Map<String, dynamic> anime;
  AnimeDetailPage({required this.anime});

  void playEpisode(BuildContext context, Map<String, dynamic> ep) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Playing ${ep['title']}... (mock player)")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(anime["title"]),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepPurple, Colors.pink],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network(anime["image"],
                height: 300,
                fit: BoxFit.cover,
                errorBuilder: (c, e, s) =>
                    Icon(Icons.broken_image, size: 100, color: Colors.grey)),
            Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    anime["title"],
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    anime["description"],
                    style: TextStyle(color: Colors.white70),
                  ),
                  SizedBox(height: 16),
                  Text("Episodes",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.pinkAccent)),
                  SizedBox(height: 8),
                  ...anime["episodes"].map<Widget>((ep) {
                    return Card(
                      color: Colors.grey[900],
                      child: ListTile(
                        title: Text(
                          "${ep['title']}",
                          style: TextStyle(color: Colors.white),
                        ),
                        trailing:
                        Icon(Icons.play_circle, color: Colors.pinkAccent),
                        onTap: () => playEpisode(context, ep),
                      ),
                    );
                  }).toList()
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
