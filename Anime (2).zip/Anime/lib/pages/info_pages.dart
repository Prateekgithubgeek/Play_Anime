import 'package:flutter/material.dart';
import 'mock_player_page.dart';
import './mock_player_page.dart';

class InfoPage extends StatelessWidget {
  final String id;
  const InfoPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    // Hardcoded anime info
    const String title = "Attack on Titan";
    const String image =
        "https://cdn.myanimelist.net/images/anime/10/47347.jpg";
    const String description =
        "Humans live in fear of the Titans... Eren Yeager and his friends "
        "join the Survey Corps to fight back.";

    // Hardcoded episodes
    final List<Map<String, dynamic>> episodes = List.generate(
      12,
          (i) => {
        "number": i + 1,
        "title": "Episode ${i + 1}",
        // give each episode same or different video url
        "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      },
    );

    return Scaffold(
      appBar: AppBar(title: const Text(title)),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network(image),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(description),
            ),
            const Divider(),
            const Text("Episodes", style: TextStyle(fontSize: 18)),
            ...episodes.map((ep) {
              return ListTile(
                title: Text("Episode ${ep['number']}: ${ep['title']}"),
                trailing: const Icon(Icons.play_circle_fill, color: Colors.red),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PlayerPage(url: ep['url']),
                    ),
                  );
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
