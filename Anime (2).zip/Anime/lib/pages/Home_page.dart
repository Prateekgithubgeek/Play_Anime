import 'package:flutter/material.dart';
import '../Services//consumet_api.dart';
import '../models/anime_models.dart';
import 'info_pages.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<AnimeSummary> animes = [];
  bool loading = true;
  String query = "";

  @override
  void initState() {
    super.initState();
    //loadTop();
  }

  Future<void> searchAnime() async {
    setState(() => loading = true);
    try {
      animes = await AnimeApi.search(query);
    } catch (_) {}
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Anime App"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              decoration: const InputDecoration(
                hintText: "Search Anime",
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => query = v,
              onSubmitted: (_) => searchAnime(),
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
              itemCount: animes.length,
              itemBuilder: (ctx, i) {
                final a = animes[i];
                return ListTile(
                  leading: Image.network(a.image, width: 60),
                  title: Text(a.title),
                  onTap: () {
                    Navigator.of(context).push(
                      PageRouteBuilder(
                        transitionDuration:
                        const Duration(milliseconds: 600),
                        pageBuilder: (context, animation,
                            secondaryAnimation) =>
                            InfoPage(id: a.id),
                        transitionsBuilder: (context, animation,
                            secondaryAnimation, child) {
                          // ✨ Fade + Scale Transition
                          return FadeTransition(
                            opacity: animation,
                            child: ScaleTransition(
                              scale: Tween<double>(begin: 0.9, end: 1.0)
                                  .animate(
                                CurvedAnimation(
                                  parent: animation,
                                  curve: Curves.easeOutBack,
                                ),
                              ),
                              child: child,
                            ),
                          );

                          // 👉 Uncomment for Slide
                          // final offsetAnimation = Tween<Offset>(
                          //   begin: const Offset(1.0, 0.0),
                          //   end: Offset.zero,
                          // ).animate(animation);
                          // return SlideTransition(
                          //   position: offsetAnimation,
                          //   child: child,
                          // );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
